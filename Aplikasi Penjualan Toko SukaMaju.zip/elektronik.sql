-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Bulan Mei 2020 pada 18.35
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elektronik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `kd_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `tanggal_masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_barang`
--

INSERT INTO `tbl_barang` (`kd_barang`, `nama_barang`, `jumlah_barang`, `harga_beli`, `harga_jual`, `tanggal_masuk`) VALUES
('B0001', 'kulkas', 0, 480000, 800000, '2020-03-03'),
('B0002', 'lemari', 0, 20000, 300000, '2020-03-03'),
('B0003', 'televisi', 0, 500000, 10000000, '2020-03-08'),
('B0004', 'ps', 0, 3000000, 2500000, '2020-03-08'),
('B0005', 'komputer', 0, 3000000, 200000, '2020-03-08'),
('B0006', 'ac', 0, 1000000, 2000000, '2020-03-08'),
('B0007', 'dispenser', 0, 480000, 500000, '2020-03-08'),
('B0008', 'dvd', 0, 300000, 400000, '2020-03-08'),
('B0009', 'mesincuci', 0, 900000, 100000, '2020-03-08'),
('B0010', 'komputer', 0, 5000, 10000, '2020-05-06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_beli`
--

CREATE TABLE `tbl_beli` (
  `nofaktur` varchar(11) NOT NULL,
  `kd_barang` varchar(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `hsatuan` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembalian` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_beli`
--

INSERT INTO `tbl_beli` (`nofaktur`, `kd_barang`, `nama_barang`, `hsatuan`, `jumlah_beli`, `harga`, `bayar`, `kembalian`, `tanggal`) VALUES
('F0001', 'B0002', 'setrika', 670000, 1, 670000, 6000000, 730000, '2018-05-15'),
('F0001', 'B0003', 'televisi', 2300000, 2, 4600000, 6000000, 730000, '2018-05-15'),
('F0002', 'B0005', 'mesin cuci', 5780000, 2, 11560000, 20000000, 40000, '2018-05-15'),
('F0002', 'B0001', 'kulkas', 1500000, 1, 1500000, 20000000, 40000, '2018-05-15'),
('F0002', 'B0003', 'televisi', 2300000, 3, 6900000, 20000000, 40000, '2018-05-15'),
('F0003', 'B0002', 'setrika', 670000, 1, 670000, 1000000, 330000, '2020-02-27'),
('F0004', 'B0001', 'kulkas', 1500000, 1, 1500000, 3000000, 1500000, '2020-02-27'),
('F0005', 'B0004', 'AC Ruangan', 2500000, 1, 2500000, 3000000, 500000, '2020-02-28'),
('F0006', 'B0001', 'kulkas', 150000, 1, 150000, 200000, 50000, '2020-03-03'),
('F0007', 'B0002', 'lemari', 300000, 1, 300000, 5000000, 4700000, '2020-03-03'),
('F0008', 'B0001', 'kulkas', 800000, 1, 800000, 20000000, 8900000, '2020-03-08'),
('F0008', 'B0002', 'lemari', 300000, 1, 300000, 20000000, 8900000, '2020-03-08'),
('F0008', 'B0003', 'televisi', 10000000, 1, 10000000, 20000000, 8900000, '2020-03-08'),
('F0009', 'B0004', 'ps', 2500000, 1, 2500000, 3000000, 500000, '2020-03-08'),
('F0010', 'B0004', 'ps', 2500000, 1, 2500000, 3000000, 500000, '2020-03-08'),
('F0011', 'B0005', 'komputer', 200000, 1, 200000, 300000, 100000, '2020-03-08'),
('F0012', 'B0006', 'ac', 2000000, 1, 2000000, 3000000, 1000000, '2020-03-08'),
('F0013', 'B0006', 'ac', 2000000, 1, 2000000, 35000000, 33000000, '2020-03-08'),
('F0014', 'B0007', 'dispenser', 500000, 1, 500000, 1000000, 100000, '2020-03-08'),
('F0014', 'B0008', 'dvd', 400000, 1, 400000, 1000000, 100000, '2020-03-08'),
('F0015', 'B0009', 'mesincuci', 100000, 1, 100000, 100000, 0, '2020-03-08'),
('F0016', 'B0009', 'mesincuci', 100000, 3, 300000, 400000, 100000, '2020-03-08'),
('F0017', 'B0009', 'mesincuci', 100000, 1, 100000, 200000, 100000, '2020-05-05'),
('F0018', 'B0009', 'mesincuci', 100000, 1, 100000, 200000, 100000, '2020-05-05'),
('F0019', 'B0009', 'mesincuci', 100000, 1, 100000, 300000, 200000, '2020-05-06'),
('F0020', 'B0009', 'mesincuci', 100000, 1, 100000, 200000, 100000, '2020-05-06'),
('F0021', 'B0009', 'mesincuci', 100000, 1, 100000, 900000, 800000, '2020-05-06'),
('F0022', 'B0009', 'mesincuci', 100000, 1, 100000, 900000, 800000, '2020-05-06'),
('F0023', 'B0010', 'komputer', 10000, 1, 10000, 90000, 80000, '2020-05-06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_login`
--

CREATE TABLE `tbl_login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telp` int(30) NOT NULL,
  `agama` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_login`
--

INSERT INTO `tbl_login` (`username`, `password`, `jenis_kelamin`, `email`, `no_telp`, `agama`, `alamat`) VALUES
('user', 'user', 'Laki-Laki', 'TugasAkhir@gmail.com.com', 12345, 'Islam', 'japan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_tmp_beli`
--

CREATE TABLE `tbl_tmp_beli` (
  `id_tmp` int(11) NOT NULL,
  `kd_barang` varchar(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `hsatuan` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Trigger `tbl_tmp_beli`
--
DELIMITER $$
CREATE TRIGGER `batal` AFTER DELETE ON `tbl_tmp_beli` FOR EACH ROW BEGIN
UPDATE tbl_barang SET jumlah_barang = jumlah_barang + OLD.jumlah_beli
WHERE kd_barang = OLD.kd_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `beli` AFTER INSERT ON `tbl_tmp_beli` FOR EACH ROW BEGIN 
UPDATE tbl_barang SET jumlah_barang = jumlah_barang - new.jumlah_beli 
WHERE kd_barang = new.`kd_barang`; 
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indeks untuk tabel `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `tbl_tmp_beli`
--
ALTER TABLE `tbl_tmp_beli`
  ADD PRIMARY KEY (`id_tmp`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_tmp_beli`
--
ALTER TABLE `tbl_tmp_beli`
  MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
